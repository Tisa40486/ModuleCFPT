﻿namespace Animfriends
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Refuge refuge = new Refuge();

            Chat chat = new Chat("Tete2Bite", "Chat", "Oui svp", 60, 125, 2, "Europeen");
        }
    }
}
